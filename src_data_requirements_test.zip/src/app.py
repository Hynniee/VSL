"""
===============================================================================
 app.py - DEMO REAL-TIME (Webcam -> Model -> van ban)  [Streamlit]
===============================================================================

Noi tat ca lai thanh 1 ung dung web chay tren trinh duyet:
  Webcam -> MediaPipe (keypoint) -> Model -> chu/tu -> hien len man hinh.

CHAY:  streamlit run src/app.py
CAI :  pip install streamlit mediapipe opencv-python torch gTTS requests

LUU Y: phai co checkpoint da train (checkpoints/best.pth) truoc khi chay.
===============================================================================
"""
import collections
import sys
import uuid
from pathlib import Path

import cv2
import numpy as np
import streamlit as st
import torch
import torch.nn.functional as F

sys.path.append(str(Path(__file__).parent))
from extract_keypoints import landmarks_to_array, mp_holistic
from model import build_model
from unicode_utils import tokens_to_text
from tts import synthesize


st.set_page_config(page_title="VSL - Nhan dang ngon ngu ky hieu", layout="wide")
st.title("Nhan dang ngon ngu ky hieu tieng Viet")


@st.cache_resource
def load_model(ckpt_path):
    ckpt = torch.load(ckpt_path, map_location="cpu")
    model = build_model(ckpt["model"], ckpt["feature_dim"], ckpt["num_classes"])
    model.load_state_dict(ckpt["state_dict"])
    model.eval()
    id2label = {v: k for k, v in ckpt["labels"].items()}
    return model, ckpt, id2label


def is_alphabet_mode(labels):
    keys = list(labels.values())[:10]
    return any(str(k).startswith(("chu_", "dau_", "thanh_")) for k in keys)


def decode_buffer(buffer, id2label, alphabet_mode):
    tokens = [id2label.get(int(idx), "?") for _, idx in buffer]
    if alphabet_mode:
        return tokens_to_text(tokens)
    return " ".join(tokens)


ckpt_path = st.sidebar.text_input("Checkpoint", "checkpoints/best.pth")
window = st.sidebar.slider("So frame moi lan doan", 16, 80, 40)
threshold = st.sidebar.slider("Nguong tin cay", 0.0, 1.0, 0.6)

if "running" not in st.session_state:
    st.session_state.running = False
if st.sidebar.button("Bat dau"):
    st.session_state.running = True
if st.sidebar.button("Dung"):
    st.session_state.running = False

col1, col2 = st.columns([3, 2])
frame_box = col1.empty()
result_box = col2.empty()
sentence_box = col2.empty()

if st.session_state.running:
    try:
        model, ckpt, id2label = load_model(ckpt_path)
    except FileNotFoundError:
        st.error("Chua tim thay checkpoint. Hay train truoc: python src/train.py")
        st.stop()

    feature_mode = ckpt["feature_mode"]
    alphabet_mode = is_alphabet_mode(id2label)
    buffer = collections.deque(maxlen=window)
    raw_buffer = collections.deque(maxlen=window)
    sentence_tokens = []
    cap = cv2.VideoCapture(0)
    with mp_holistic.Holistic(model_complexity=1, refine_face_landmarks=False) as holistic:
        while st.session_state.running and cap.isOpened():
            ok, img = cap.read()
            if not ok:
                st.warning("Khong doc duoc frame tu webcam.")
                break
            res = holistic.process(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
            arr = landmarks_to_array(res)
            buffer.append(arr)
            raw_buffer.append(arr)

            label, conf = "...", 0.0
            if len(buffer) == window:
                arr_batch = np.stack(buffer)
                if feature_mode == "hands":
                    arr_batch = arr_batch[:, -42:, :]
                x = torch.from_numpy(arr_batch.reshape(arr_batch.shape[0], -1).astype("float32")).unsqueeze(0)
                lengths = torch.tensor([x.shape[1]])
                with torch.no_grad():
                    prob = F.softmax(model(x, lengths), dim=1)[0]
                conf, idx = float(prob.max()), int(prob.argmax())
                label = id2label.get(idx, "?")

            frame_box.image(img, channels="BGR")
            result_box.markdown(f"### Du doan: {label}\n\nDo tin cay: {conf*100:.0f}%")

            if conf >= threshold and not (sentence_tokens and sentence_tokens[-1][0] == idx):
                sentence_tokens.append((idx, label))

            decoded = decode_buffer(sentence_tokens[-50:] if sentence_tokens else [], id2label, alphabet_mode)
            sentence_box.markdown(f"## Cau: {decoded}")

    cap.release()

    if sentence_tokens and st.button("Phat amm cau"):
        text = decode_buffer(sentence_tokens, id2label, alphabet_mode)
        if text.strip():
            out_path = f"tmp_audio_{uuid.uuid4().hex}.mp3"
            try:
                synthesize(text.strip(), out_path=out_path)
                st.audio(out_path)
            except Exception as e:
                st.error(f"Loi phat amm: {e}")
else:
    st.info("Nhan **Bat dau** o thanh ben de mo webcam.")
